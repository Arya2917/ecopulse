# backend/services/compliance_ai.py
# ═══════════════════════════════════════════════════════════════════════════════
# AI Compliance Advisor
# Reads compliance scan results (PII/PHI findings, regulation scores)
# from the completed audit and generates a legal + compliance analysis.
# ═══════════════════════════════════════════════════════════════════════════════

from __future__ import annotations
import logging

from services.ollama_service import generate

logger = logging.getLogger("ecopulse.compliance_ai")


def _build_prompt(compliance: dict) -> str:
    findings      = compliance.get("findings",       [])
    column_report = compliance.get("column_report",  {})
    reg_scores    = compliance.get("regulation_scores", {})
    summary_stats = compliance.get("summary",        {})

    # Regulation scores
    reg_lines = []
    for reg in ["GDPR", "HIPAA", "CCPA", "ISO27001", "PCI_DSS"]:
        score = reg_scores.get(reg)
        if score is not None:
            status = "PASS" if score >= 0.7 else "RISK" if score >= 0.4 else "FAIL"
            reg_lines.append(f"  - {reg}: {score:.2f} ({status})")
    if not reg_lines:
        reg_lines = ["  - (regulation scores not available)"]

    # Severity breakdown
    high   = [f for f in findings if (f.get("severity") or "").upper() == "HIGH"]
    medium = [f for f in findings if (f.get("severity") or "").upper() == "MEDIUM"]
    low    = [f for f in findings if (f.get("severity") or "").upper() == "LOW"]

    # PII columns
    pii_cols = []
    for col, info in column_report.items():
        if info.get("pii_detected") or info.get("entities"):
            ents = [e.get("entity_type", str(e)) if isinstance(e, dict) else str(e)
                    for e in info.get("entities", [])]
            sev  = info.get("severity", info.get("max_severity", "UNKNOWN"))
            pii_cols.append(f"  - {col}: {', '.join(ents[:3]) or 'PII detected'}  [{sev}]")

    pii_block = "\n".join(pii_cols[:10]) if pii_cols else "  - (no PII columns detected)"

    # Sample findings detail
    finding_lines = []
    for f in (high + medium)[:8]:
        col   = f.get("column", f.get("field", "unknown"))
        etype = f.get("entity_type", f.get("type", "PII"))
        sev   = f.get("severity", "UNKNOWN")
        reg   = f.get("regulation", "")
        finding_lines.append(f"  - [{sev}] Column '{col}': {etype} {f'({reg})' if reg else ''}")
    findings_block = "\n".join(finding_lines) if finding_lines else "  - (no critical findings)"

    prompt = f"""You are a senior legal and data compliance advisor specializing in AI and data privacy regulations.
You have been given a compliance scan report from an AI system audit.

REGULATION COMPLIANCE SCORES (0.0 = fail, 1.0 = full compliance):
{chr(10).join(reg_lines)}

PII/PHI DETECTED COLUMNS:
{pii_block}

FINDINGS SUMMARY:
  - Total findings: {len(findings)}
  - HIGH severity: {len(high)}
  - MEDIUM severity: {len(medium)}
  - LOW severity: {len(low)}

KEY FINDINGS (HIGH and MEDIUM severity):
{findings_block}

INSTRUCTIONS
============
Provide a compliance analysis in plain English. No LaTeX. No markdown # headers.
Reference the actual regulation scores and findings above.

1. COMPLIANCE SUMMARY
Overall compliance posture in 3-4 sentences. Which regulations are at risk?

2. RISK LEVEL
State one of: LOW / MEDIUM / HIGH / CRITICAL — justify with specific findings.

3. REGULATORY VIOLATIONS
For each failing regulation, what specific rules are being violated and why?

4. LEGAL IMPLICATIONS
What are the real-world legal consequences of these findings? (fines, enforcement, reputational risk)

5. RECOMMENDED ACTIONS
List 5-6 specific, actionable steps to remediate the findings immediately.

6. COMPLIANCE ROADMAP
A phased 30-60-90 day plan to achieve full compliance across all relevant regulations."""

    return prompt


def _parse_response(text: str) -> dict:
    return {
        "summary":             _extract_section(text, "1. COMPLIANCE SUMMARY",   "2."),
        "risk":                _extract_section(text, "2. RISK LEVEL",           "3."),
        "violations":          _extract_section(text, "3. REGULATORY VIOLATIONS","4."),
        "legal_implications":  _extract_section(text, "4. LEGAL IMPLICATIONS",  "5."),
        "recommendations":     _extract_section(text, "5. RECOMMENDED ACTIONS", "6."),
        "roadmap":             _extract_section(text, "6. COMPLIANCE ROADMAP",   None),
        "raw": text,
    }


def _extract_section(text: str, start_marker: str, end_marker: str | None) -> str:
    try:
        idx_start = text.index(start_marker) + len(start_marker)
        if end_marker:
            try:
                idx_end = text.index(end_marker, idx_start)
                return text[idx_start:idx_end].strip()
            except ValueError:
                pass
        return text[idx_start:].strip()
    except ValueError:
        return ""


def analyze_compliance(job_id: str, jobs: dict) -> dict:
    job = jobs.get(job_id)
    if not job:
        raise KeyError(f"Job {job_id} not found")

    compliance = job.get("module_results", {}).get("compliance")
    if not compliance:
        raise ValueError("Compliance results not available. Run a compliance audit first.")
    if compliance.get("error"):
        raise ValueError(f"Compliance module errored: {compliance['error']}")

    prompt   = _build_prompt(compliance)
    logger.info("Calling Ollama for compliance analysis (job=%s)", job_id)
    raw_text = generate(prompt)
    result   = _parse_response(raw_text)
    result["job_id"] = job_id
    return result